
import React, { useEffect, useRef, useState } from "react";

const ROLES={SUPER_ADMIN:"SUPER_ADMIN",ADMIN:"ADMIN",EMPLOYEE:"EMPLOYEE"};
const PRIORITY={HIGH:"HIGH",MEDIUM:"MEDIUM",LOW:"LOW"};
const TASK_STATUS={OPEN:"OPEN",IN_PROGRESS:"IN_PROGRESS",DONE:"DONE"};
const ATT_STATUS={PENDING:"PENDING",APPROVED:"APPROVED",REJECTED:"REJECTED"};
const EXP_STATUS={PENDING:"PENDING",APPROVED:"APPROVED",REJECTED:"REJECTED"};
const uid=(p="id")=>`${p}_${Math.random().toString(36).slice(2,10)}`;
const fmtHrs=n=>`${(n||0).toFixed(2)}h`;
const diffHours=(s,e)=>!s||!e?0:Math.max(0,(new Date(e)-new Date(s))/36e5);
const addDays=(isoLike,days)=>{const base=isoLike?new Date(isoLike):new Date();const d=new Date(base);d.setDate(base.getDate()+days);return d.toISOString()};
const toLocalDate=iso=>{if(!iso)return"";const d=new Date(iso),p=n=>String(n).padStart(2,'0');return`${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}`};

const seedUsers=[
  {id:"u_sadmin",name:"Super Admin",email:"sadmin@example.com",password:"super123",role:ROLES.SUPER_ADMIN,monthlySalary:0,monthlyHours:0,hourlyRate:0},
  {id:"u_admin",name:"Admin",email:"admin@example.com",password:"admin123",role:ROLES.ADMIN,monthlySalary:0,monthlyHours:0,hourlyRate:0},
  {id:"u_e1",name:"Aarav Mehta",email:"aarav@example.com",password:"pass1",role:ROLES.EMPLOYEE,monthlySalary:0,monthlyHours:0,hourlyRate:200},
  {id:"u_e2",name:"Riya Patel",email:"riya@example.com",password:"pass2",role:ROLES.EMPLOYEE,monthlySalary:0,monthlyHours:0,hourlyRate:220},
  {id:"u_e3",name:"Kabir Shah",email:"kabir@example.com",password:"pass3",role:ROLES.EMPLOYEE,monthlySalary:0,monthlyHours:0,hourlyRate:180}
];
const seedShifts=[{id:"s_g",name:"General",start:"09:30",end:"18:30",timezone:"Asia/Kolkata"},{id:"s_e",name:"Evening",start:"12:00",end:"21:00",timezone:"Asia/Kolkata"}];

const db={users:[...seedUsers],shifts:[...seedShifts],holidays:[],chatThreads:[],messages:[],tasks:[],attendance:[],expenses:[],unread:{ADMIN:0,SUPER_ADMIN:0},taskUnread:{}};

const notifyBrowser=(title,body)=>{try{if("Notification" in window){if(Notification.permission==="granted"){new Notification(title,{body});}else if(Notification.permission!=="denied"){Notification.requestPermission().then(p=>{if(p==="granted")new Notification(title,{body});});}}}catch{}};

const Card=({title,children,actions})=>(<div className="bg-white rounded-2xl shadow p-4 border border-gray-100"><div className="flex items-center justify-between mb-3"><h3 className="text-base font-semibold text-gray-800">{title}</h3><div className="flex gap-2">{actions}</div></div><div>{children}</div></div>);
const Section=({children})=>(<div className="grid gap-4">{children}</div>);
const Button=({children,onClick,type="button",variant="primary",className="",disabled=false})=>{const s={primary:"bg-indigo-600 hover:bg-indigo-700 text-white",outline:"bg-white text-gray-800 border border-gray-300 hover:bg-gray-50",danger:"bg-red-600 hover:bg-red-700 text-white",success:"bg-green-600 hover:bg-green-700 text-white"};return(<button type={type} onClick={onClick} disabled={disabled} className={`rounded-xl px-3 py-2 text-sm font-medium ${s[variant]} disabled:opacity-50 ${className}`}>{children}</button>)};
const TextInput=({value,onChange,placeholder,type="text",className="",onEnter})=>(<input type={type} value={value} onChange={e=>onChange(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"&&onEnter)onEnter(e)}} placeholder={placeholder} className={`w-full rounded-xl border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 ${className}`}/>);
const Select=({value,onChange,children,className=""})=>(<select value={value} onChange={e=>onChange(e.target.value)} className={`w-full rounded-xl border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 ${className}`}>{children}</select>);
const Pill=({children,className=""})=>(<span className={`px-2 py-0.5 rounded-full text-xs font-medium border ${className}`}>{children}</span>);

const effectiveHourly=u=>{const hrs=+u?.monthlyHours||0,sal=+u?.monthlySalary||0;return hrs>0&&sal>0?sal/hrs:+u?.hourlyRate||0};

const getOrCreateThreadBetween=(a,b)=>{const [x,y]=[a,b].sort();let t=db.chatThreads.find(q=>q.a===x&&q.b===y);if(!t){t={id:uid("thr"),a:x,b:y,createdAt:new Date().toISOString()};db.chatThreads.push(t);}return t};
const sendMessage=(threadId,senderId,text,file)=>{const m={id:uid("msg"),threadId,senderId,text,file,createdAt:new Date().toISOString()};db.messages.push(m);const thr=db.chatThreads.find(t=>t.id===threadId);if(thr){const rcpt=senderId===thr.a?thr.b:thr.a;const ru=db.users.find(u=>u.id===rcpt);const key=ru?.role===ROLES.SUPER_ADMIN?ROLES.SUPER_ADMIN:ru?.role===ROLES.ADMIN?ROLES.ADMIN:rcpt;db.unread[key]=(db.unread[key]||0)+1;notifyBrowser("New chat message",`From ${db.users.find(u=>u.id===senderId)?.name||"User"}`);}return m};
const clearUnreadForChat=id=>{db.unread[id]=0};
const unreadCountForChat=(role,empId)=>role===ROLES.SUPER_ADMIN?db.unread.SUPER_ADMIN||0:role===ROLES.ADMIN?db.unread.ADMIN||0:db.unread[empId]||0;

const bumpTaskUnread=(uid,p)=>{const cur=db.taskUnread[uid]||{count:0,highest:null},ord={HIGH:3,MEDIUM:2,LOW:1};db.taskUnread[uid]={count:cur.count+1,highest:!cur.highest||ord[p]>ord[cur.highest]?p:cur.highest}};
const clearTaskUnread=uid=>{db.taskUnread[uid]={count:0,highest:null}};
const createTask=input=>{const t={id:uid("task"),status:TASK_STATUS.OPEN,createdAt:new Date().toISOString(),...input};db.tasks.push(t);bumpTaskUnread(input.assigneeId,input.priority);return t};
const updateTask=(id,patch)=>{const t=db.tasks.find(x=>x.id===id);if(!t)return;Object.assign(t,patch);if(patch.status===TASK_STATUS.DONE){t.completedAt=new Date().toISOString()}return t};

const punchIn=(uid,shiftId)=>{const d=new Date().toISOString().slice(0,10);if(db.attendance.find(a=>a.userId===uid&&a.date===d&&a.punchInAt&&!a.punchOutAt))throw new Error("Already punched in");const r={id:uid("att"),userId:uid,shiftId,date:d,punchInAt:new Date().toISOString(),status:ATT_STATUS.PENDING};db.attendance.push(r);return r};
const punchOut=uid=>{const d=new Date().toISOString().slice(0,10);const r=db.attendance.find(a=>a.userId===uid&&a.date===d&&a.punchInAt&&!a.punchOutAt);if(!r)throw new Error("Not punched in");r.punchOutAt=new Date().toISOString();return r};
const approveAttendance=(id,approverId,ok=true)=>{const r=db.attendance.find(a=>a.id===id);if(!r)return;r.status=ok?ATT_STATUS.APPROVED:ATT_STATUS.REJECTED;r.approverId=approverId;return r};

const submitExpense=input=>{const e={id:uid("exp"),currency:"INR",status:EXP_STATUS.PENDING,createdAt:new Date().toISOString(),...input};db.expenses.push(e);return e};
const decideExpense=(id,approverId,ok=true)=>{const e=db.expenses.find(x=>x.id===id);if(!e)return;e.status=ok?EXP_STATUS.APPROVED:EXP_STATUS.REJECTED;e.approverId=approverId;return e};

function UsersManage(){
  const [uidv,setUidv]=useState(""); const [name,setName]=useState(""); const [email,setEmail]=useState(""); const [pwd,setPwd]=useState(""); const [role,setRole]=useState(ROLES.EMPLOYEE); const [,force]=useState(0);
  const create=(e)=>{e.preventDefault();try{if(!uidv.trim()||!name.trim()||!pwd.trim())throw new Error("All fields required");if(db.users.some(u=>u.id===uidv.trim()))throw new Error("User ID already exists");db.users.push({id:uidv.trim(),name:name.trim(),email:email.trim(),password:pwd.trim(),role,monthlySalary:0,monthlyHours:0,hourlyRate:0});setUidv("");setName("");setEmail("");setPwd("");alert("User created")}catch(err){alert(err.message)}};
  const del=id=>{if(!confirm("Delete user?"))return;const i=db.users.findIndex(u=>u.id===id);if(i>=0){db.users.splice(i,1);alert("Deleted");force(x=>x+1)}};
  const reset=id=>{const u=db.users.find(x=>x.id===id);if(!u)return;const np=prompt("New password for "+u.name+":");if(!np)return;u.password=np;alert("Password updated")};
  const setR=(id,newR)=>{const u=db.users.find(x=>x.id===id);if(!u)return;u.role=newR;alert("Role updated");force(x=>x+1)};
  const users=db.users.slice().sort((a,b)=>a.name.localeCompare(b.name));
  return(<Section>
    <Card title="Create User">
      <form onSubmit={create} className="grid md:grid-cols-5 gap-3">
        <TextInput value={name} onChange={setName} placeholder="Full name *" onEnter={create}/>
        <TextInput value={uidv} onChange={setUidv} placeholder="User ID * (unique)" onEnter={create}/>
        <TextInput value={email} onChange={setEmail} placeholder="Email" onEnter={create}/>
        <TextInput type="password" value={pwd} onChange={setPwd} placeholder="Password *" onEnter={create}/>
        <Select value={role} onChange={setRole}>
          <option value={ROLES.EMPLOYEE}>Employee</option>
          <option value={ROLES.ADMIN}>Admin</option>
          <option value={ROLES.SUPER_ADMIN}>Super Admin</option>
        </Select>
        <div className="md:col-span-5 flex justify-end"><Button type="submit">Create</Button></div>
      </form>
    </Card>
    <Card title="All Users">
      <div className="overflow-x-auto"><table className="min-w-full text-sm"><thead className="text-left text-gray-600"><tr><th className="py-2 pr-4">User ID</th><th className="py-2 pr-4">Name</th><th className="py-2 pr-4">Role</th><th className="py-2 pr-4">Email</th><th className="py-2 pr-4">Actions</th></tr></thead><tbody>{users.map(u=>(<tr key={u.id} className="border-t"><td className="py-2 pr-4">{u.id}</td><td className="py-2 pr-4">{u.name}</td><td className="py-2 pr-4"><Select value={u.role} onChange={(v)=>setR(u.id,v)} className="w-36"><option value={ROLES.EMPLOYEE}>Employee</option><option value={ROLES.ADMIN}>Admin</option><option value={ROLES.SUPER_ADMIN}>Super Admin</option></Select></td><td className="py-2 pr-4">{u.email||"—"}</td><td className="py-2 pr-4 flex gap-2"><Button variant="outline" onClick={()=>reset(u.id)}>Reset Password</Button><Button variant="danger" onClick={()=>del(u.id)}>Delete</Button></td></tr>))}{users.length===0&&<tr><td colSpan={5} className="py-2 text-gray-500">No users.</td></tr>}</tbody></table></div>
    </Card>
  </Section>)}

function Chat({me,role,onViewed}){
  const [cp,setCp]=useState("");
  const [thread,setThread]=useState(null);
  const [msgs,setMsgs]=useState([]);
  const [text,setText]=useState("");
  const fileRef=useRef(null);const endRef=useRef(null);
  const selectable=db.users.filter(u=>{if(u.id===me.id)return false;if(role===ROLES.SUPER_ADMIN)return true;if(role===ROLES.ADMIN)return u.role===ROLES.EMPLOYEE;return u.role===ROLES.ADMIN||u.role===ROLES.SUPER_ADMIN});
  useEffect(()=>{if(!cp&&selectable[0])setCp(selectable[0].id)},[selectable.length]);
  useEffect(()=>{if(!cp)return;const t=getOrCreateThreadBetween(me.id,cp);setThread(t);setMsgs(db.messages.filter(m=>m.threadId===t.id).sort((a,b)=>a.createdAt.localeCompare(b.createdAt)))},[cp]);
  useEffect(()=>{endRef.current?.scrollIntoView({behavior:"smooth"})},[msgs.length]);
  useEffect(()=>{onViewed&&onViewed()},[]);
  const onSend=(e)=>{e&&e.preventDefault();if(!thread)return;if(!text&&!fileRef.current?.files?.length)return;let file;if(fileRef.current?.files?.[0]){const f=fileRef.current.files[0];file={name:f.name,size:f.size,url:URL.createObjectURL(f),type:f.type};fileRef.current.value=""}const msg=sendMessage(thread.id,me.id,text,file);setMsgs(p=>[...p,msg]);setText("")};
  return(<Card title="Chat" actions={<Select value={cp} onChange={setCp} className="w-52">{selectable.map(u=><option key={u.id} value={u.id}>{u.name} ({u.role})</option>)}</Select>}>
    <div className="h-80 flex flex-col">
      <div className="flex-1 overflow-y-auto space-y-2 pr-1">{msgs.map(m=>(<div key={m.id} className={`max-w-[85%] rounded-2xl px-3 py-2 text-sm shadow ${m.senderId===me.id?"ml-auto bg-indigo-600 text-white":"bg-gray-100"}`}><div className="whitespace-pre-wrap">{m.text}</div>{m.file&&(<a href={m.file.url} target="_blank" rel="noreferrer" className={`block underline mt-1 ${m.senderId===me.id?"text-white":"text-indigo-700"}`}>📎 {m.file.name}</a>)}<div className="text-[10px] opacity-70 mt-1">{new Date(m.createdAt).toLocaleString()}</div></div>))}<div ref={endRef}/></div>
      <form onSubmit={onSend} className="mt-3 flex items-center gap-2">
        <TextInput value={text} onChange={setText} placeholder="Type a message…" onEnter={onSend}/>
        <input ref={fileRef} type="file" className="text-xs"/>
        <Button type="submit">Send</Button>
      </form>
    </div>
  </Card>)
}

function Tasks({me,role,onViewed}){
  const [filter,setFilter]=useState("ALL"),[priority,setPriority]=useState("ALL");
  const [title,setTitle]=useState(""),[desc,setDesc]=useState(""),[prio,setPrio]=useState(PRIORITY.MEDIUM),[assignee,setAssignee]=useState(me.id),[due,setDue]=useState(""),[rem,setRem]=useState(""),[datePick,setDatePick]=useState({});
  const [showCreate,setShowCreate]=useState(false);
  const[,force]=useState(0);
  useEffect(()=>{onViewed&&onViewed()},[]);
  const all=(()=>{let l=db.tasks.filter(t=>role!==ROLES.EMPLOYEE?true:(t.assigneeId===me.id||t.creatorId===me.id));if(filter!=="ALL")l=l.filter(t=>t.status===filter);if(priority!=="ALL")l=l.filter(t=>t.priority===priority);return l.sort((a,b)=>(a.dueDate||"").localeCompare(b.dueDate||"")||(a.createdAt||"").localeCompare(b.createdAt||""))})();
  const selfAssigned=all.filter(t=>t.assigneeId===me.id&&t.creatorId===me.id);
  const assignedToMe=all.filter(t=>t.assigneeId===me.id&&t.creatorId!==me.id);
  const assignedToOthers=all.filter(t=>t.creatorId===me.id&&t.assigneeId!==me.id);
  const onCreate=(e)=>{e.preventDefault();if(!title)return;const t=createTask({title,description:desc,priority:prio,assigneeId:assignee,creatorId:me.id,dueDate:due||null,reminderAt:rem||null});if(t.assigneeId!==me.id)notifyBrowser("New task",`Assigned to ${db.users.find(u=>u.id===t.assigneeId)?.name||"user"}`);setTitle("");setDesc("");setPrio(PRIORITY.MEDIUM);setDue("");setRem("");setAssignee(me.id);setShowCreate(false);force(x=>x+1)};
  const toggleDone=t=>{updateTask(t.id,{status:t.status===TASK_STATUS.DONE?TASK_STATUS.OPEN:TASK_STATUS.DONE});force(x=>x+1)};
  const moveTomorrow=t=>{const base=t.dueDate||new Date().toISOString();updateTask(t.id,{dueDate:addDays(base,1)});force(x=>x+1)};
  const moveToDate=t=>{const d=datePick[t.id];if(!d)return;updateTask(t.id,{dueDate:new Date(`${d}T09:00:00`).toISOString()});force(x=>x+1)};
  const prioBadge=p=>(<Pill className={p===PRIORITY.HIGH?"border-red-300 bg-red-50 text-red-700":p===PRIORITY.MEDIUM?"border-amber-300 bg-amber-50 text-amber-700":"border-emerald-300 bg-emerald-50 text-emerald-700"}>{p}</Pill>);
  const canAssignAll=role===ROLES.ADMIN||role===ROLES.SUPER_ADMIN;const assignOpts=canAssignAll?db.users:db.users.filter(u=>u.id===me.id);
  const Row=({t,allowReschedule})=>(<div className="flex items-center justify-between bg-gray-50 rounded-xl p-3"><div className="min-w-0"><div className="flex items-center gap-2"><input type="checkbox" className="h-4 w-4" checked={t.status===TASK_STATUS.DONE} onChange={()=>toggleDone(t)}/><div className={`font-medium truncate ${t.status===TASK_STATUS.DONE?"line-through text-gray-500":"text-gray-800"}`}>{t.title}</div>{prioBadge(t.priority)}</div><div className="text-xs text-gray-500 mt-1 flex flex-wrap gap-2">{t.dueDate&&<span>Due: {new Date(t.dueDate).toLocaleDateString()}</span>}<span>Assignee: {db.users.find(u=>u.id===t.assigneeId)?.name}</span><span>Status: {t.status.replace("_"," ")}</span></div></div><div className="flex items-center gap-2">{allowReschedule&&(<div className="flex items-center gap-2"><Button variant="outline" onClick={()=>moveTomorrow(t)}>Tomorrow</Button><input type="date" className="border rounded-xl px-2 py-1 text-xs" value={datePick[t.id]||toLocalDate(t.dueDate)} onChange={e=>setDatePick({...datePick,[t.id]:e.target.value})}/><Button variant="outline" onClick={()=>moveToDate(t)}>Move</Button></div>)}</div></div>);
  return(<Section>
    <Card title="Tasks" actions={<div className="flex gap-2"><Select value={filter} onChange={setFilter} className="w-36"><option value="ALL">All</option>{Object.values(TASK_STATUS).map(s=><option key={s} value={s}>{s}</option>)}</Select><Select value={priority} onChange={setPriority} className="w-36"><option value="ALL">Any Priority</option>{Object.values(PRIORITY).map(s=><option key={s} value={s}>{s}</option>)}</Select><Button variant="outline" onClick={()=>setShowCreate(s=>!s)}>{showCreate?"Close":"Create Task"}</Button></div>}>
      <div className="grid md:grid-cols-3 gap-3">
        <div><div className="text-sm font-semibold mb-2">Self-assigned</div><div className="grid gap-2">{selfAssigned.length===0&&<div className="text-sm text-gray-500">No tasks.</div>}{selfAssigned.map(t=><Row key={t.id} t={t} allowReschedule/>)}</div></div>
        <div><div className="text-sm font-semibold mb-2">Assigned to me (by others)</div><div className="grid gap-2">{assignedToMe.length===0&&<div className="text-sm text-gray-500">No tasks.</div>}{assignedToMe.map(t=><Row key={t.id} t={t} allowReschedule={false}/>)}</div></div>
        <div><div className="text-sm font-semibold mb-2">Assigned to others (created by me)</div><div className="grid gap-2">{assignedToOthers.length===0&&<div className="text-sm text-gray-500">No tasks.</div>}{assignedToOthers.map(t=><Row key={t.id} t={t} allowReschedule/>)}</div></div>
      </div>
    </Card>
    {showCreate&&(<Card title="Create Task">
      <form onSubmit={onCreate} className="grid gap-3">
        <TextInput value={title} onChange={setTitle} placeholder="Title *" onEnter={onCreate}/>
        <TextInput value={desc} onChange={setDesc} placeholder="Description"/>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          <Select value={prio} onChange={setPrio}>{Object.values(PRIORITY).map(p=><option key={p} value={p}>{p}</option>)}</Select>
          <Select value={assignee} onChange={setAssignee}>{assignOpts.map(u=><option key={u.id} value={u.id}>{u.name} ({u.role})</option>)}</Select>
          <TextInput type="datetime-local" value={due} onChange={setDue}/>
        </div>
        <div className="grid grid-cols-2 gap-3"><TextInput type="datetime-local" value={rem} onChange={setRem}/></div>
        <div className="flex justify-end"><Button type="submit">Add Task</Button></div>
      </form>
    </Card>)}
  </Section>)
}

function Attendance({me,role}){
  const[,force]=useState(0);
  const today=new Date().toISOString().slice(0,10);
  const [shift,setShift]=useState(db.shifts[0]?.id||"");
  const open=db.attendance.find(a=>a.userId===me.id&&a.date===today&&a.punchInAt&&!a.punchOutAt);
  const doIn=()=>{try{punchIn(me.id,shift)}catch(e){alert(e.message)}finally{force(x=>x+1)}};
  const doOut=()=>{try{punchOut(me.id)}catch(e){alert(e.message)}finally{force(x=>x+1)}};
  const decide=(id,ok)=>{try{approveAttendance(id,me.id,ok)}finally{force(x=>x+1)}};
  const list=(role===ROLES.ADMIN)?db.attendance.slice().sort((a,b)=>(b.date+(b.punchInAt||"")).localeCompare(a.date+(a.punchInAt||""))):db.attendance.filter(a=>a.userId===me.id);
  const pending=(role===ROLES.ADMIN)?db.attendance.filter(a=>a.status===ATT_STATUS.PENDING).length:0;
  return(<Section>
    {role===ROLES.EMPLOYEE&&(<Card title="Today"><div className="grid gap-3 md:grid-cols-3 md:items-end">
      <div className="md:col-span-2 grid gap-3"><div className="text-sm text-gray-600">Date: {today}</div><Select value={shift} onChange={setShift} className="md:w-60" disabled={!!open}>{db.shifts.map(s=><option key={s.id} value={s.id}>{s.name} ({s.start}–{s.end})</option>)}</Select></div>
      <div className="flex gap-2 md:justify-end"><Button onClick={doIn} disabled={!!open}>Punch In</Button><Button variant="outline" onClick={doOut} disabled={!open}>Punch Out</Button></div>
    </div>{open&&<div className="mt-3 text-sm text-gray-600">In: {new Date(open.punchInAt).toLocaleTimeString()} · Out: — · Status: {open.status}</div>}</Card>)}
    {(role===ROLES.ADMIN)&&(<Card title="Approvals" actions={<Pill className="border-amber-300 bg-amber-50 text-amber-700">Pending: {pending}</Pill>}><div className="text-sm text-gray-600">Approve or reject submitted sessions.</div></Card>)}
    <Card title={(role===ROLES.ADMIN)?"Attendance – Session Approvals":"My Attendance Sessions"}>
      <div className="overflow-x-auto"><table className="min-w-full text-sm"><thead className="text-left text-gray-600"><tr><th className="py-2 pr-4">User</th><th className="py-2 pr-4">Date</th><th className="py-2 pr-4">Shift</th><th className="py-2 pr-4">In</th><th className="py-2 pr-4">Out</th><th className="py-2 pr-4">Hours</th><th className="py-2 pr-4">Status</th>{(role===ROLES.ADMIN)&&<th className="py-2">Actions</th>}</tr></thead><tbody>{list.map(a=>(<tr key={a.id} className="border-t"><td className="py-2 pr-4">{db.users.find(u=>u.id===a.userId)?.name}</td><td className="py-2 pr-4">{a.date}</td><td className="py-2 pr-4">{db.shifts.find(s=>s.id===a.shiftId)?.name}</td><td className="py-2 pr-4">{a.punchInAt?new Date(a.punchInAt).toLocaleTimeString():"—"}</td><td className="py-2 pr-4">{a.punchOutAt?new Date(a.punchOutAt).toLocaleTimeString():"—"}</td><td className="py-2 pr-4">{a.punchOutAt?fmtHrs(diffHours(a.punchInAt,a.punchOutAt)):"—"}</td><td className="py-2 pr-4"><Pill className={a.status===ATT_STATUS.APPROVED?"border-emerald-300 bg-emerald-50 text-emerald-700":a.status===ATT_STATUS.REJECTED?"border-red-300 bg-red-50 text-red-700":"border-amber-300 bg-amber-50 text-amber-700"}>{a.status}</Pill></td>{(role===ROLES.ADMIN)&&<td className="py-2 flex gap-2"><Button variant="success" onClick={()=>decide(a.id,true)} disabled={a.status!==ATT_STATUS.PENDING||!a.punchOutAt}>Approve</Button><Button variant="danger" onClick={()=>decide(a.id,false)} disabled={a.status!==ATT_STATUS.PENDING||!a.punchOutAt}>Reject</Button></td>}</tr>))}{list.length===0&&<tr><td className="py-3 text-gray-500" colSpan={(role===ROLES.ADMIN)?8:7}>No records.</td></tr>}</tbody></table></div>
    </Card>
  </Section>)
}

function Reports(){
  const[tab,setTab]=useState("attendance"),[emp,setEmp]=useState(""),[approvedOnly,setApprovedOnly]=useState(true),[month,setMonth]=useState(new Date().toISOString().slice(0,7));
  const start=new Date(`${month}-01T00:00:00`),end=new Date(new Date(start).setMonth(start.getMonth()+1));
  const employees=db.users.filter(u=>u.role===ROLES.EMPLOYEE);
  const sessions=emp?db.attendance.filter(a=>a.userId===emp&&new Date(a.date)>=start&&new Date(a.date)<end&&(approvedOnly?a.status===ATT_STATUS.APPROVED:true)):[];
  const byDay={};for(const a of sessions){if(!a.punchInAt||!a.punchOutAt)continue;byDay[a.date]=byDay[a.date]||{date:a.date,rows:[],sessions:0,hours:0};byDay[a.date].rows.push(a);byDay[a.date].sessions++;byDay[a.date].hours+=diffHours(a.punchInAt,a.punchOutAt)}
  const dayRows=Object.values(byDay).sort((a,b)=>a.date.localeCompare(b.date));
  const totalHours=dayRows.reduce((s,r)=>s+r.hours,0);
  const rate=effectiveHourly(db.users.find(u=>u.id===emp)||{});const payable=totalHours*(rate||0);
  const [openDay,setOpenDay]=useState(null);
  return(<Section>
    <Card title="Reports" actions={<div className="flex gap-2 items-center"><Button variant="outline" onClick={()=>setTab("attendance")}>Attendance</Button><Button variant="outline" onClick={()=>setTab("expenses")}>Expenses</Button></div>}>
      {tab==="attendance"&&(<div className="grid gap-3">
        <div className="flex flex-wrap items-end gap-3">
          <div><div className="text-xs text-gray-500 mb-1">Employee</div><select className="border rounded-xl px-3 py-2 text-sm" value={emp} onChange={e=>setEmp(e.target.value)}><option value="">— Select —</option>{employees.map(u=><option key={u.id} value={u.id}>{u.name}</option>)}</select></div>
          <div><div className="text-xs text-gray-500 mb-1">Month</div><input type="month" value={month} onChange={e=>setMonth(e.target.value)} className="border rounded-xl px-3 py-2 text-sm"/></div>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={approvedOnly} onChange={e=>setApprovedOnly(e.target.checked)}/> Approved only</label>
        </div>
        {!emp?<div className="text-sm text-gray-500">Select an employee.</div>:(
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="text-left text-gray-600"><tr><th className="py-2 pr-4">Date</th><th className="py-2 pr-4">Sessions</th><th className="py-2 pr-4">Total Hours</th><th className="py-2 pr-4">Payable (₹)</th></tr></thead>
              <tbody>
                {dayRows.map(d=>(
                  <React.Fragment key={d.date}>
                    <tr className="border-t hover:bg-gray-50 cursor-pointer" onClick={()=>setOpenDay(openDay===d.date?null:d.date)}>
                      <td className="py-2 pr-4">{d.date}</td>
                      <td className="py-2 pr-4">{d.sessions}</td>
                      <td className="py-2 pr-4">{fmtHrs(d.hours)}</td>
                      <td className="py-2 pr-4">{(d.hours*(rate||0)).toFixed(2)}</td>
                    </tr>
                    {openDay===d.date&&(
                      <tr>
                        <td colSpan={4} className="bg-gray-50">
                          <div className="overflow-x-auto p-2">
                            <table className="min-w-full text-xs">
                              <thead><tr><th className="py-1 pr-3">Shift</th><th className="py-1 pr-3">In</th><th className="py-1 pr-3">Out</th><th className="py-1 pr-3">Hours</th><th className="py-1 pr-3">Status</th></tr></thead>
                              <tbody>
                                {d.rows.map(r=>(
                                  <tr key={r.id} className="border-t">
                                    <td className="py-1 pr-3">{db.shifts.find(s=>s.id===r.shiftId)?.name}</td>
                                    <td className="py-1 pr-3">{new Date(r.punchInAt).toLocaleTimeString()}</td>
                                    <td className="py-1 pr-3">{new Date(r.punchOutAt).toLocaleTimeString()}</td>
                                    <td className="py-1 pr-3">{fmtHrs(diffHours(r.punchInAt,r.punchOutAt))}</td>
                                    <td className="py-1 pr-3">{r.status}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
                {dayRows.length===0&&<tr><td colSpan={4} className="py-2 text-gray-500">No sessions.</td></tr>}
                <tr className="border-t font-semibold">
                  <td className="py-2 pr-4">Total</td>
                  <td className="py-2 pr-4">{dayRows.reduce((s,r)=>s+r.sessions,0)}</td>
                  <td className="py-2 pr-4">{fmtHrs(totalHours)}</td>
                  <td className="py-2 pr-4">{(totalHours*(rate||0)).toFixed(2)}</td>
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </div>)}
      {tab==="expenses"&&(<div className="text-sm text-gray-500">Use the Expenses tab for detailed approvals and lists.</div>)}
    </Card>
  </Section>)
}

function Expenses({me,role}){
  const[amount,setAmount]=useState(""),[category,setCategory]=useState("Travel"),[date,setDate]=useState(new Date().toISOString().slice(0,10)),[remarks,setRemarks]=useState("");
  const fileRef=useRef(null);const[,force]=useState(0);
  const myList=(role===ROLES.ADMIN)?db.expenses:db.expenses.filter(e=>e.userId===me.id);
  const onSubmit=e=>{e.preventDefault();const f=fileRef.current?.files?.[0];const receipt=f?{name:f.name,size:f.size,url:URL.createObjectURL(f)}:undefined;submitExpense({userId:me.id,category,amount:+(amount||0),expenseDate:date,remarks,receipt});setAmount("");setRemarks("");if(fileRef.current)fileRef.current.value="";force(x=>x+1)};
  const decide=(id,ok)=>{decideExpense(id,me.id,ok);force(x=>x+1)};
  return(<Section>
    {role===ROLES.EMPLOYEE&&(<Card title="New Expense"><form onSubmit={onSubmit} className="grid gap-3 md:grid-cols-2">
      <TextInput type="number" value={amount} onChange={setAmount} placeholder="Amount (₹)" onEnter={onSubmit}/>
      <Select value={category} onChange={setCategory}>{"Travel,Food,Supplies,Other".split(",").map(c=><option key={c} value={c}>{c}</option>)}</Select>
      <TextInput type="date" value={date} onChange={setDate}/>
      <input ref={fileRef} type="file" className="text-sm"/>
      <div className="md:col-span-2"><TextInput value={remarks} onChange={setRemarks} placeholder="Remarks" onEnter={onSubmit}/></div>
      <div className="md:col-span-2 flex justify-end"><Button type="submit">Submit</Button></div>
    </form></Card>)}
    <Card title={(role===ROLES.ADMIN)?"Expenses – Review":"My Expenses"}>
      <div className="overflow-x-auto"><table className="min-w-full text-sm"><thead className="text-left text-gray-600"><tr>{(role===ROLES.ADMIN)&&<th className="py-2 pr-4">User</th>}<th className="py-2 pr-4">Date</th><th className="py-2 pr-4">Category</th><th className="py-2 pr-4">Amount</th><th className="py-2 pr-4">Remarks</th><th className="py-2 pr-4">Receipt</th><th className="py-2 pr-4">Status</th>{(role===ROLES.ADMIN)&&<th className="py-2">Actions</th>}</tr></thead><tbody>{myList.map(e=>(<tr key={e.id} className="border-t">{(role===ROLES.ADMIN)&&<td className="py-2 pr-4">{db.users.find(u=>u.id===e.userId)?.name}</td>}<td className="py-2 pr-4">{e.expenseDate}</td><td className="py-2 pr-4">{e.category}</td><td className="py-2 pr-4">₹{(+e.amount).toFixed(2)}</td><td className="py-2 pr-4 max-w-[220px] truncate" title={e.remarks}>{e.remarks||"—"}</td><td className="py-2 pr-4">{e.receipt?<a className="underline text-indigo-700" href={e.receipt.url} target="_blank" rel="noreferrer">View</a>:"—"}</td><td className="py-2 pr-4"><Pill className={e.status===EXP_STATUS.APPROVED?"border-emerald-300 bg-emerald-50 text-emerald-700":e.status===EXP_STATUS.REJECTED?"border-red-300 bg-red-50 text-red-700":"border-amber-300 bg-amber-50 text-amber-700"}>{e.status}</Pill></td>{(role===ROLES.ADMIN)&&<td className="py-2 flex gap-2"><Button variant="success" onClick={()=>decide(e.id,true)} disabled={e.status!==EXP_STATUS.PENDING}>Approve</Button><Button variant="danger" onClick={()=>decide(e.id,false)} disabled={e.status!==EXP_STATUS.PENDING}>Reject</Button></td>}</tr>))}{myList.length===0&&<tr><td className="py-3 text-gray-500" colSpan={(role===ROLES.ADMIN)?8:7}>No expenses.</td></tr>}</tbody></table></div>
    </Card>
  </Section>)
}

function AdminDashboard(){
  const total=db.tasks.length;
  const byStatus={OPEN:db.tasks.filter(t=>t.status===TASK_STATUS.OPEN).length,IN_PROGRESS:db.tasks.filter(t=>t.status===TASK_STATUS.IN_PROGRESS).length,DONE:db.tasks.filter(t=>t.status===TASK_STATUS.DONE).length};
  const pending=db.attendance.filter(a=>a.status===ATT_STATUS.PENDING).length;
  const month=new Date().toISOString().slice(0,7);
  const exp=db.expenses.filter(e=>(e.expenseDate||"").startsWith(month)).reduce((s,e)=>s+(+e.amount||0),0);
  const recent=db.tasks.slice(-5).reverse();
  return(<Section>
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      <Card title="Tasks"><div className="text-2xl font-semibold">{total}</div></Card>
      <Card title="Attendance Pending"><div className="text-2xl font-semibold">{pending}</div></Card>
      <Card title="This Month Expenses"><div className="text-2xl font-semibold">₹{exp.toFixed(0)}</div></Card>
      <Card title="Employees"><div className="text-2xl font-semibold">{db.users.filter(u=>u.role===ROLES.EMPLOYEE).length}</div></Card>
    </div>
    <Card title="Task Status Summary">
      <div className="grid grid-cols-3 gap-2 text-sm">
        <div className="bg-gray-50 rounded-xl p-2 flex items-center justify-between"><span>Open</span><b>{byStatus.OPEN}</b></div>
        <div className="bg-gray-50 rounded-xl p-2 flex items-center justify-between"><span>In progress</span><b>{byStatus.IN_PROGRESS}</b></div>
        <div className="bg-gray-50 rounded-xl p-2 flex items-center justify-between"><span>Done</span><b>{byStatus.DONE}</b></div>
      </div>
      <div className="mt-3 text-sm text-gray-600">Recent tasks</div>
      <div className="grid gap-2 mt-1">{recent.map(t=>(<div key={t.id} className="bg-white border rounded-xl p-2 flex items-center justify-between"><div className="min-w-0"><div className="font-medium truncate">{t.title}</div><div className="text-xs text-gray-500">{db.users.find(u=>u.id===t.assigneeId)?.name} • {t.status} • {t.priority}</div></div><Pill className="border-gray-300">{t.dueDate?new Date(t.dueDate).toLocaleDateString():"No due"}</Pill></div>))||<div className="text-sm text-gray-500">No tasks.</div>}</div>
    </Card>
  </Section>)
}

export default function App(){
  const[role,setRole]=useState(ROLES.SUPER_ADMIN),[employeeId,setEmployeeId]=useState(db.users.find(u=>u.role===ROLES.EMPLOYEE)?.id||"");
  const me=role===ROLES.SUPER_ADMIN?db.users.find(u=>u.role===ROLES.SUPER_ADMIN):role===ROLES.ADMIN?db.users.find(u=>u.role===ROLES.ADMIN):db.users.find(u=>u.id===employeeId);
  const[tab,setTab]=useState(role===ROLES.EMPLOYEE?'home':'dashboard');
  useEffect(()=>{setTab(role===ROLES.EMPLOYEE?'home':'dashboard')},[role]);
  useEffect(()=>{try{if("Notification" in window && Notification.permission==="default"){Notification.requestPermission();}}catch{}},[]);
  const[chatUnread,setChatUnread]=useState(0),[taskBadge,setTaskBadge]=useState({count:0,highest:null});
  const attPending=(role===ROLES.ADMIN)?db.attendance.filter(a=>a.status===ATT_STATUS.PENDING).length:0;
  useEffect(()=>{setChatUnread(unreadCountForChat(role,employeeId))},[role,employeeId,db.messages.length]);
  useEffect(()=>{const b=db.taskUnread[(role===ROLES.EMPLOYEE?employeeId:me?.id)]||{count:0,highest:null};setTaskBadge(b)},[role,employeeId,db.tasks.length]);
  const onChatViewed=()=>{clearUnreadForChat(role===ROLES.SUPER_ADMIN?ROLES.SUPER_ADMIN:role===ROLES.ADMIN?ROLES.ADMIN:employeeId);setChatUnread(0)};
  const onTasksViewed=()=>{if(role===ROLES.EMPLOYEE){clearTaskUnread(employeeId);setTaskBadge({count:0,highest:null})}};
  if(!me)return <div className="p-4">No users seeded.</div>;
  const items=(role===ROLES.SUPER_ADMIN?[{key:"dashboard",label:"Dashboard"},{key:"tasks",label:"Tasks"},{key:"attendance",label:"Attendance"},{key:"expenses",label:"Expenses"},{key:"chat",label:"Chat"},{key:"reports",label:"Reports"},{key:"users",label:"Users"}]:role===ROLES.ADMIN?[{key:"dashboard",label:"Dashboard"},{key:"tasks",label:"Tasks"},{key:"attendance",label:"Attendance"},{key:"expenses",label:"Expenses"},{key:"chat",label:"Chat"},{key:"reports",label:"Reports"}]:[{key:"home",label:"Home"},{key:"tasks",label:"Tasks"},{key:"attendance",label:"Attendance"},{key:"expenses",label:"Expenses"},{key:"chat",label:"Chat"}]);
  return(
  <div className="min-h-screen bg-gradient-to-b from-indigo-50 to-white text-gray-900">
    <header className="sticky top-0 z-10 backdrop-blur bg-white/80 border-b border-gray-200">
      <div className="max-w-6xl mx-auto px-3 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2"><div className="h-8 w-8 rounded-2xl bg-indigo-600 text-white grid place-items-center font-bold">AE</div><div className="font-semibold">Admin–Employee App</div></div>
        <div className="flex items-center gap-2">
          <Select value={role} onChange={setRole} className="w-40"><option value={ROLES.SUPER_ADMIN}>Super Admin</option><option value={ROLES.ADMIN}>Admin</option><option value={ROLES.EMPLOYEE}>Employee</option></Select>
          {role===ROLES.EMPLOYEE&&(<Select value={employeeId} onChange={setEmployeeId} className="w-44">{db.users.filter(u=>u.role===ROLES.EMPLOYEE).map(u=><option key={u.id} value={u.id}>{u.name}</option>)}</Select>)}
          <Button variant="outline" onClick={()=>notifyBrowser("Test notification","This is how notifications look.")}>Test Notification</Button>
        </div>
      </div>
    </header>
    <main className="max-w-6xl mx-auto px-3 py-4 grid gap-4">
      <div className="flex overflow-x-auto gap-2">
        {items.map(i=>{const isChat=i.key==='chat',isAtt=i.key==='attendance',isTasks=i.key==='tasks',dot=isChat?chatUnread>0:isAtt?attPending>0:isTasks?taskBadge.count>0:false;const dotClass=isTasks?(taskBadge.highest==='HIGH'?'bg-red-600':'bg-amber-500'):'bg-red-500';const count=isAtt?attPending:undefined;return(<button key={i.key} onClick={()=>setTab(i.key)} className={`relative px-3 py-2 rounded-xl text-sm border ${tab===i.key?"bg-indigo-600 text-white border-indigo-600":"bg-white hover:bg-gray-50"}`}>{i.label}{dot&&<span className={`absolute -top-1 -right-1 h-2.5 w-2.5 rounded-full ${dotClass}`}/>} {typeof count==='number'&&count>0&&(<span className="absolute -top-2 -right-3 text-[10px] bg-red-600 text-white rounded-full px-1">{count}</span>)}</button>)})}
      </div>
      <div className="grid gap-4">
        {role!==ROLES.EMPLOYEE&&tab==='dashboard'&&<AdminDashboard/>}
        {role===ROLES.EMPLOYEE&&tab==='home'&&(<Section><Card title="Welcome"><div className="text-sm text-gray-700">Use the tabs to record attendance, expenses, tasks and chat.</div></Card></Section>)}
        {tab==='tasks'&&<Tasks me={me} role={role} onViewed={onTasksViewed}/>}
        {tab==='attendance'&&<Attendance me={me} role={role}/>}
        {tab==='expenses'&&<Expenses me={me} role={role}/>}
        {tab==='chat'&&<Chat me={me} role={role} onViewed={onChatViewed}/>}
        {tab==='reports'&&<Reports/>}
        {tab==='users'&&<UsersManage/>}
      </div>
    </main>
    <footer className="pb-24 md:pb-6 text-center text-xs text-gray-500">v2.0 • Demo only</footer>
  </div>);
}
